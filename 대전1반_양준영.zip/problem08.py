# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def caesar(word, n):
    # 문자열을 추가하는 반복문을 돌릴 때에는 초깃값으로 ''로 설정합니다.
    cae_word = ''
    for i in word:
         # cae_1에는 i를 정수로 변환하여 n을 더한 값을 나타냅니다.
         # ord의 범위에 따라 케이스를 나누고 그 안에서 cae_1의 케이스를 나누어
         # 계산합니다.
        cae_1 = ord(i) + n
        if 97 <= ord(i) <= 122:
            if 97 <= cae_1 <= 122:
                cae_word += chr(cae_1)
            elif cae_1 > 122:
                cae_word += chr((cae_1 - 123) % 26 + 97) 
        elif 65 <= ord(i) <= 90:
            if 65 <= cae_1 <= 90:
                cae_word += chr(cae_1)
            elif cae_1 >90:
                cae_word += chr((cae_1 - 91) % 26 + 65)

    return cae_word

        



    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
########## 코드 변경 금지 ############
if __name__ == '__main__':
    print(caesar('apple', 5))      # fuuqj
    print(caesar('ssafy', 1))      # ttbgz
    print(caesar('Python', 10))    # Zidryx
